
import React from 'react';
import Sidebar from '@/components/Sidebar';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import SkillsSection from '@/components/SkillsSection';
import EducationSection from '@/components/EducationSection';
import ProjectsSection from '@/components/ProjectsSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

const Index = () => {
  return (
    <div className="flex min-h-screen bg-gradient-to-br from-white to-blue-50">
      <Sidebar />
      <main className="flex-1 ml-20 md:ml-72 overflow-y-auto">
        <div className="wrapper">
          <HeroSection />
          <AboutSection />
          <SkillsSection />
          <EducationSection />
          <ProjectsSection />
          <ContactSection />
          <Footer />
        </div>
      </main>
    </div>
  );
};

export default Index;
