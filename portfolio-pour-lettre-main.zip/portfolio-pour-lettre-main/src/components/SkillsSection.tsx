
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle2 } from 'lucide-react';

const SkillsSection = () => {
  const skillCategories = [
    {
      title: "Langages de programmation",
      skills: ["Python", "JavaScript", "TypeScript", "Java", "C/C++", "PHP"]
    },
    {
      title: "Développement Web",
      skills: ["React.js", "Vue.js", "HTML5", "CSS3", "Node.js", "Express", "Tailwind CSS", "Bootstrap"]
    },
    {
      title: "Base de données",
      skills: ["MySQL", "PostgreSQL", "MongoDB", "Firebase", "Redis"]
    },
    {
      title: "DevOps & Outils",
      skills: ["Git", "Docker", "Linux", "AWS", "CI/CD", "Kubernetes"]
    }
  ];

  return (
    <section id="competences" className="py-20 bg-portfolio-light-gray">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-portfolio-slate mb-4 font-montserrat">Mes Compétences</h2>
          <div className="h-1 w-24 bg-portfolio-indigo mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-portfolio-slate mb-4 font-montserrat">{category.title}</h3>
                <div className="grid grid-cols-2 gap-3">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="flex items-center">
                      <CheckCircle2 className="h-4 w-4 mr-2 text-portfolio-indigo" />
                      <span className="text-portfolio-gray">{skill}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
