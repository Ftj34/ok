
import React from 'react';
import { Mail, Phone, MapPin, Linkedin, Github } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

const ContactSection = () => {
  const { toast } = useToast();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send the form data to a backend
    toast({
      title: "Message envoyé !",
      description: "Merci pour votre message, je vous répondrai dès que possible.",
      variant: "default",
    });
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-portfolio-slate mb-4 font-montserrat">Me Contacter</h2>
          <div className="h-1 w-24 bg-portfolio-indigo mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold text-portfolio-slate mb-6 font-montserrat">Informations de contact</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white mr-4">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-portfolio-slate">Email</h4>
                  <p className="text-portfolio-gray">jeandupont@example.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white mr-4">
                  <Phone size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-portfolio-slate">Téléphone</h4>
                  <p className="text-portfolio-gray">+33 6 12 34 56 78</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white mr-4">
                  <MapPin size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-medium text-portfolio-slate">Localisation</h4>
                  <p className="text-portfolio-gray">Paris, France</p>
                </div>
              </div>
            </div>
            
            <h3 className="text-2xl font-semibold text-portfolio-slate mt-10 mb-6 font-montserrat">Réseaux sociaux</h3>
            
            <div className="flex space-x-4">
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white hover:bg-indigo-700 transition-colors"
              >
                <Linkedin size={20} />
              </a>
              <a 
                href="https://github.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white hover:bg-indigo-700 transition-colors"
              >
                <Github size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold text-portfolio-slate mb-6 font-montserrat">Envoyez-moi un message</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-portfolio-slate font-medium">Nom</label>
                  <Input id="name" placeholder="Votre nom" required className="w-full" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-portfolio-slate font-medium">Email</label>
                  <Input id="email" type="email" placeholder="Votre email" required className="w-full" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="subject" className="text-portfolio-slate font-medium">Sujet</label>
                <Input id="subject" placeholder="Sujet de votre message" required className="w-full" />
              </div>
              
              <div className="space-y-2">
                <label htmlFor="message" className="text-portfolio-slate font-medium">Message</label>
                <Textarea id="message" placeholder="Votre message" required className="w-full min-h-[150px]" />
              </div>
              
              <Button 
                type="submit" 
                className="bg-portfolio-indigo hover:bg-indigo-700 text-white py-3 px-6 rounded-lg"
              >
                Envoyer le message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
