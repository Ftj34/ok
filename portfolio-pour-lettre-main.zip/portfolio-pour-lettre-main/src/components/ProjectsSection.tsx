
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Github, ExternalLink } from 'lucide-react';

type ProjectProps = {
  title: string;
  description: string;
  technologies: string[];
  image: string;
  githubLink?: string;
  liveLink?: string;
};

const Project = ({ title, description, technologies, image, githubLink, liveLink }: ProjectProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow group">
      <div className="relative h-56 bg-gray-200">
        <div className="w-full h-full flex items-center justify-center text-gray-500">
          {image ? (
            <img src={image} alt={title} className="w-full h-full object-cover" />
          ) : (
            <span>Image du projet</span>
          )}
        </div>
        <div className="absolute inset-0 bg-portfolio-indigo bg-opacity-70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
          {githubLink && (
            <a 
              href={githubLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white rounded-full p-2 hover:bg-portfolio-blue hover:text-white transition-colors"
            >
              <Github size={20} />
            </a>
          )}
          {liveLink && (
            <a 
              href={liveLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white rounded-full p-2 hover:bg-portfolio-blue hover:text-white transition-colors"
            >
              <ExternalLink size={20} />
            </a>
          )}
        </div>
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold text-portfolio-slate mb-2 font-montserrat">{title}</h3>
        <p className="text-portfolio-gray mb-4">{description}</p>
        <div className="flex flex-wrap gap-2">
          {technologies.map((tech, index) => (
            <span 
              key={index} 
              className="bg-blue-100 text-portfolio-blue px-2 py-1 rounded text-xs font-medium"
            >
              {tech}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

const ProjectsSection = () => {
  const projects = [
    {
      title: "Application de Gestion de Tâches",
      description: "Une application web permettant de gérer des tâches personnelles et professionnelles avec des fonctionnalités de rappel.",
      technologies: ["React", "Redux", "Node.js", "MongoDB"],
      image: "",
      githubLink: "https://github.com",
      liveLink: "https://example.com"
    },
    {
      title: "Portfolio Personnel",
      description: "Un site portfolio responsive présentant mes compétences, projets et expériences professionnelles.",
      technologies: ["React", "Tailwind CSS", "TypeScript"],
      image: "",
      githubLink: "https://github.com",
      liveLink: "https://example.com"
    },
    {
      title: "API REST de Bibliothèque",
      description: "Une API permettant de gérer un catalogue de livres, les emprunts et les utilisateurs.",
      technologies: ["Node.js", "Express", "PostgreSQL", "JWT"],
      image: "",
      githubLink: "https://github.com"
    },
    {
      title: "Application Météo",
      description: "Une application mobile affichant les prévisions météorologiques basées sur la géolocalisation de l'utilisateur.",
      technologies: ["React Native", "API OpenWeatherMap", "Context API"],
      image: "",
      githubLink: "https://github.com",
      liveLink: "https://example.com"
    },
    {
      title: "Jeu de Plateforme 2D",
      description: "Un jeu de plateforme développé en utilisant le moteur Unity avec des niveaux personnalisés.",
      technologies: ["Unity", "C#", "Blender"],
      image: "",
      githubLink: "https://github.com"
    },
    {
      title: "Système de Reconnaissance d'Images",
      description: "Un modèle d'IA permettant de reconnaître et classifier différents objets dans des images.",
      technologies: ["Python", "TensorFlow", "OpenCV", "NumPy"],
      image: "",
      githubLink: "https://github.com"
    }
  ];

  return (
    <section id="projets" className="py-20 bg-portfolio-light-gray">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-portfolio-slate mb-4 font-montserrat">Mes Projets</h2>
          <div className="h-1 w-24 bg-portfolio-indigo mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Project key={index} {...project} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
