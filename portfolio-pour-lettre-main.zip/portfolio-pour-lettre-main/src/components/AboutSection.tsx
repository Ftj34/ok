
import React from 'react';

const AboutSection = () => {
  return (
    <section id="a-propos" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-portfolio-slate mb-4 font-montserrat">À Propos de Moi</h2>
          <div className="h-1 w-24 bg-portfolio-indigo mx-auto rounded-full"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <p className="text-lg text-portfolio-gray mb-6 leading-relaxed">
            Je suis étudiant en informatique à l'Université de Paris, actuellement en 3ème année de licence. Passionné par la technologie depuis mon plus jeune âge, j'ai développé une forte appétence pour le développement web et l'intelligence artificielle.
          </p>
          <p className="text-lg text-portfolio-gray mb-6 leading-relaxed">
            Mon parcours académique m'a permis d'acquérir de solides compétences techniques, que je complète par des projets personnels et des stages en entreprise. Je suis constamment en quête d'apprentissage et cherche à me perfectionner dans les technologies les plus récentes.
          </p>
          <p className="text-lg text-portfolio-gray leading-relaxed">
            En dehors de mes études, je suis un passionné de cybersécurité et participe régulièrement à des CTF (Capture The Flag). J'aime également partager mes connaissances à travers des articles de blog et des tutoriels.
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
