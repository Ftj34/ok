
import React from 'react';
import { GraduationCap, Briefcase } from 'lucide-react';

const EducationItem = ({ icon, period, title, institution, description }: {
  icon: React.ReactNode;
  period: string;
  title: string;
  institution: string;
  description: string;
}) => {
  return (
    <div className="flex mb-10">
      <div className="mr-4">
        <div className="bg-portfolio-indigo w-12 h-12 rounded-full flex items-center justify-center text-white">
          {icon}
        </div>
      </div>
      <div>
        <span className="bg-blue-100 text-portfolio-blue px-3 py-1 rounded-full text-sm font-medium">
          {period}
        </span>
        <h3 className="text-xl font-semibold mt-2 text-portfolio-slate">{title}</h3>
        <h4 className="text-md font-medium text-portfolio-indigo">{institution}</h4>
        <p className="text-portfolio-gray mt-2">{description}</p>
      </div>
    </div>
  );
};

const EducationSection = () => {
  const education = [
    {
      icon: <GraduationCap size={24} />,
      period: "2021 - Présent",
      title: "Licence en Informatique",
      institution: "Université de Paris",
      description: "Spécialisation en développement web et intelligence artificielle. Participation à divers projets collaboratifs."
    },
    {
      icon: <GraduationCap size={24} />,
      period: "2019 - 2021",
      title: "BTS Services Informatiques aux Organisations",
      institution: "Lycée Louis Armand, Paris",
      description: "Option SLAM (Solutions Logicielles et Applications Métiers). Développement de solutions web et mobiles."
    },
    {
      icon: <GraduationCap size={24} />,
      period: "2019",
      title: "Baccalauréat Scientifique",
      institution: "Lycée Condorcet, Paris",
      description: "Spécialité Mathématiques, mention Bien."
    }
  ];

  const experience = [
    {
      icon: <Briefcase size={24} />,
      period: "Été 2023",
      title: "Stage Développeur Full Stack",
      institution: "TechFrance, Paris",
      description: "Développement d'une application web de gestion de projet utilisant React, Node.js et MongoDB."
    },
    {
      icon: <Briefcase size={24} />,
      period: "Été 2022",
      title: "Stage Développeur Front-end",
      institution: "AgenceWeb, Lyon",
      description: "Intégration de maquettes et développement de composants réutilisables avec Vue.js."
    }
  ];

  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-portfolio-slate mb-4 font-montserrat">Formation & Expérience</h2>
          <div className="h-1 w-24 bg-portfolio-indigo mx-auto rounded-full"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-semibold text-portfolio-slate mb-6 font-montserrat">Formation</h3>
            {education.map((item, index) => (
              <EducationItem key={index} {...item} />
            ))}
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold text-portfolio-slate mb-6 font-montserrat">Expérience</h3>
            {experience.map((item, index) => (
              <EducationItem key={index} {...item} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default EducationSection;
