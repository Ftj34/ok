
import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <a href="#" className="font-montserrat font-bold text-2xl text-portfolio-indigo">Portfolio</a>
          
          {/* Mobile menu button */}
          <button onClick={toggleMenu} className="md:hidden text-portfolio-slate">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          
          {/* Desktop menu */}
          <ul className="hidden md:flex space-x-8">
            <li>
              <button 
                onClick={() => scrollToSection('accueil')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                Accueil
              </button>
            </li>
            <li>
              <button 
                onClick={() => scrollToSection('a-propos')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                À propos
              </button>
            </li>
            <li>
              <button 
                onClick={() => scrollToSection('competences')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                Compétences
              </button>
            </li>
            <li>
              <button 
                onClick={() => scrollToSection('education')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                Formation
              </button>
            </li>
            <li>
              <button 
                onClick={() => scrollToSection('projets')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                Projets
              </button>
            </li>
            <li>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
              >
                Contact
              </button>
            </li>
          </ul>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white mt-4 p-4 rounded-lg shadow-lg">
            <ul className="flex flex-col space-y-4">
              <li>
                <button 
                  onClick={() => scrollToSection('accueil')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  Accueil
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('a-propos')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  À propos
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('competences')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  Compétences
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('education')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  Formation
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('projets')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  Projets
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="font-medium text-portfolio-slate hover:text-portfolio-indigo transition-colors"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
