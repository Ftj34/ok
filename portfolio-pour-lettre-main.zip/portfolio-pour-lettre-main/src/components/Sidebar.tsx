
import React, { useState, useEffect } from 'react';
import { Menu, X, Clock, Home, User, Code, GraduationCap, BookOpen, FolderKanban, Mail } from 'lucide-react';

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('accueil');
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  // Update date and time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['accueil', 'a-propos', 'competences', 'education', 'projets', 'contact'];
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom >= 150) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      if (window.innerWidth < 768) {
        setIsOpen(false);
      }
    }
  };

  // Format date and time in French
  const formatDateTime = (date: Date) => {
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric'
    };
    
    const frenchDate = date.toLocaleDateString('fr-FR', options);
    // Capitalize first letter
    const capitalizedDate = frenchDate.charAt(0).toUpperCase() + frenchDate.slice(1);
    
    // Format time as HH:MM:SS
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    const seconds = date.getSeconds().toString().padStart(2, '0');
    const time = `${hours}:${minutes}:${seconds}`;
    
    return `${capitalizedDate} ${time}`;
  };

  // Mapping des sections avec leurs icônes
  const navigationItems = [
    { id: 'accueil', text: 'Accueil', icon: <Home size={20} /> },
    { id: 'a-propos', text: 'À propos', icon: <User size={20} /> },
    { id: 'competences', text: 'Compétences', icon: <Code size={20} /> },
    { id: 'education', text: 'Formation', icon: <GraduationCap size={20} /> },
    { id: 'projets', text: 'Projets', icon: <FolderKanban size={20} /> },
    { id: 'contact', text: 'Contact', icon: <Mail size={20} /> }
  ];

  return (
    <>
      {/* Mobile toggle button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed top-6 left-6 z-50 bg-white p-2 rounded-full shadow-md text-portfolio-indigo"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside 
        className={`fixed h-full bg-white shadow-xl z-40 transition-all duration-300 ease-in-out
                   ${isOpen ? 'left-0' : '-left-full md:left-0'}
                   w-72 md:w-72`}
      >
        <div className="h-full flex flex-col py-10 px-6">
          <div className="mb-8">
            <h1 className="font-montserrat font-bold text-3xl text-portfolio-indigo">Portfolio</h1>
            <p className="text-portfolio-gray mt-2">Jean Dupont</p>
          </div>
          
          {/* Clock */}
          <div className="mb-6 flex items-center text-portfolio-slate bg-portfolio-light-gray p-3 rounded-lg">
            <Clock size={18} className="mr-2 text-portfolio-indigo" />
            <span className="text-sm font-medium">{formatDateTime(currentDateTime)}</span>
          </div>
          
          <nav className="flex-1">
            <ul className="space-y-8">
              {navigationItems.map(item => (
                <li key={item.id}>
                  <button
                    onClick={() => scrollToSection(item.id)}
                    className={`group flex items-center w-full relative transition-all duration-300
                              ${activeSection === item.id 
                                ? 'text-portfolio-indigo font-medium' 
                                : 'text-portfolio-gray hover:text-portfolio-slate'}`}
                  >
                    <span className={`absolute left-0 w-1 h-full rounded-r-md transform transition-all duration-300 
                                    ${activeSection === item.id 
                                      ? 'bg-portfolio-indigo opacity-100' 
                                      : 'opacity-0 group-hover:opacity-50 bg-portfolio-indigo'}`} />
                    <div className="ml-3 flex items-center">
                      <span className={`mr-3 transition-colors ${activeSection === item.id ? 'text-portfolio-indigo' : 'text-portfolio-gray group-hover:text-portfolio-slate'}`}>
                        {item.icon}
                      </span>
                      <span>{item.text}</span>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          
          <div className="mt-auto">
            <div className="flex space-x-4">
              <a href="#" className="text-portfolio-gray hover:text-portfolio-indigo transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-github"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
              </a>
              <a href="#" className="text-portfolio-gray hover:text-portfolio-indigo transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-linkedin"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect width="4" height="12" x="2" y="9"></rect><circle cx="4" cy="4" r="2"></circle></svg>
              </a>
              <a href="#" className="text-portfolio-gray hover:text-portfolio-indigo transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-mail"><rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path></svg>
              </a>
            </div>
            <p className="text-xs text-portfolio-gray mt-4">&copy; {new Date().getFullYear()} Jean Dupont</p>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
