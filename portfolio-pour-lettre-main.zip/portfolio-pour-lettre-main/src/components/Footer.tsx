
import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-10 text-center">
      <div className="container mx-auto px-4 md:px-6">
        <p className="text-gray-500">
          Conçu et développé avec <span className="text-red-500">♥</span> par Jean Dupont
        </p>
      </div>
    </footer>
  );
};

export default Footer;
