
import React from 'react';
import { ArrowRight, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section id="accueil" className="min-h-screen flex flex-col justify-center relative overflow-hidden py-20">
      {/* Background animation elements */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 right-10 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 left-20 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 right-40 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>
      
      <div className="container mx-auto px-6 z-10">
        <div className="flex flex-col md:flex-row items-center gap-16">
          <div className="md:w-1/2 animate-fade-in relative z-10">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 font-montserrat leading-tight text-portfolio-slate">
              Bonjour, je suis<br />
              <span className="text-portfolio-indigo relative inline-block">
                Jean Dupont
                <span className="absolute bottom-2 left-0 w-full h-2 bg-indigo-100"></span>
              </span>
            </h1>
            <p className="text-xl text-portfolio-gray mb-10 max-w-md">
              Étudiant en informatique passionné par le développement web et l'intelligence artificielle.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-portfolio-indigo hover:bg-indigo-700 text-white py-6 px-8 rounded-xl flex items-center gap-2 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
                size="lg"
              >
                Me contacter <ArrowRight size={20} />
              </Button>
              <Button
                variant="outline"
                className="border-2 border-portfolio-indigo text-portfolio-indigo hover:bg-portfolio-indigo hover:text-white py-6 px-8 rounded-xl flex items-center gap-2 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
                size="lg"
              >
                Télécharger CV <Download size={20} />
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center relative z-10">
            <div className="relative w-72 h-72 md:w-96 md:h-96 animate-float">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-portfolio-indigo to-purple-500 opacity-10 blur-2xl animate-pulse"></div>
              <div className="relative w-full h-full overflow-hidden rounded-full border-4 border-portfolio-indigo shadow-2xl">
                <div className="w-full h-full bg-gradient-to-br from-white to-gray-100 flex items-center justify-center">
                  <span className="text-gray-600 text-lg font-medium">Photo</span>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-portfolio-indigo rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg">
                <span>Dev</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
